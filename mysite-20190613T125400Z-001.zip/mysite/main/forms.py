from django import forms
from django.forms.widgets import PasswordInput, TextInput, EmailInput
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm

class loginForm(AuthenticationForm):
    #username = forms.CharField(widget=TextInput(attrs={'placeholder': 'Username', 'style': 'border-radius: 3px; margin-left: 5px; margin-right: 5px;'}))
    username = forms.CharField(widget=TextInput(attrs={'placeholder': 'Username', 'class': 'form-control-sm mr-sm-2'}))
    password = forms.CharField(widget=PasswordInput(attrs={'placeholder':'Password', 'class': 'form-control-sm mr-sm-2'}))

class signupForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, widget=TextInput(attrs={'placeholder': 'First Name', 'class': 'form-control-sm mr-sm-2'}))
    last_name = forms.CharField(max_length=30, widget=TextInput(attrs={'placeholder': 'Last Name', 'class': 'form-control-sm mr-sm-2'}))
    email = forms.CharField(max_length=75, widget=EmailInput(attrs={'placeholder': 'Email', 'class': 'form-control-sm mr-sm-2'}))
    # username = forms.CharField(widget=TextInput(attrs={'placeholder': 'Username', 'class': 'form-control-sm mr-sm-2'}))
    # password1 = forms.CharField(widget=PasswordInput(attrs={'placeholder':'Password', 'class': 'form-control-sm mr-sm-2'}))
    # password2 = forms.CharField(widget=PasswordInput(attrs={'placeholder':'Confirm PAssword', 'class': 'form-control-sm mr-sm-2'}))
    class Meta(UserCreationForm.Meta):
        fields = ('username','first_name','last_name', 'email')



