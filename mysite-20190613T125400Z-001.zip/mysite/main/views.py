from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Movie
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
import operator 
from .forms import signupForm, loginForm
# Create your views here.

def homepage(request):
    #path = r"C:\Users\andr439d\Documents\flick\mysite\main\static\img\New folder"
    #img_list =os.listdir(path) """
    form = loginForm
    MovieSortAddDate = Movie.objects.all().order_by("-MovieReleaseDate")
    MovieSortMostComments = Movie.objects.all().order_by("-CommentCounter")
    return render(request=request,
                  template_name="main/home.html",
                  context={"Movies": Movie.objects.all,
                           "MoviesByDate": MovieSortAddDate[:5],
                           "MoviesByCommentCount": MovieSortMostComments[:5],
                           "loginForm": form})

def register(request):
    form1 = loginForm
    if request.method == "POST":
        form = signupForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            messages.info(request, f"Your account, {username}, has been created and you are logged in")
            login(request, user)
            return redirect("main:homepage")

        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")

            return render(request = request,
                          template_name = "main/register.html",
                          context={"registerForm":form,
                                   "loginForm": form1})

    form = signupForm
    return render(request = request,
                  template_name = "main/register.html",
                  context={"registerForm":form,
                           "loginForm": form1})

def movie(request, movie_id=""):
    form = loginForm
    if not isinstance(movie_id, int):
        return render(request=request,
                      template_name="main/allmovies.html",
                      context={"Movies":Movie.objects.all,
                               "loginForm": form})

    elif isinstance(movie_id, int):
        return render(request=request,
                      template_name="main/movie.html",
                      context={"Movie":Movie.objects.filter(id=movie_id),
                               "movie_id":movie_id,
                               "loginForm": form})

def logout_request(request):
    logout(request)
    messages.info(request, "logged out succesfully")
    return(redirect("main:homepage"))

def login_request(request):
    if request.method == "POST":
        form = loginForm(request, data=request.POST) 
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as: {username}")
                return redirect("main:homepage")
            else:
                messages.error(request, "invalid username or password")
        else:
            messages.error(request, "invalid username or password")
    else:
        return redirect("main:homepage")
