
import django
from django.db import models
from django.contrib.auth.models import User
import datetime

# Create your models here.
class Movie(models.Model):
    MovieTitle = models.CharField(max_length=200)   
    MovieReleaseDate = models.DateField("MovieReleaseDate")
    MovieAgeRating = models.IntegerField()
    MovieDuration = models.IntegerField()
    MoviePosterUrl = models.CharField(max_length=2083)
    MovieTrailerUrl = models.CharField(max_length=2083)
    MovieAddDate = models.DateField("MovieAddDate", default=django.utils.timezone.now)
    CommentCounter = models.IntegerField(default=0)

    def __str__(self):
        return self.MovieTitle

class personel(models.Model):
    personFirstName = models.CharField(max_length=30)
    personLastName = models.CharField(max_length=30)

class role(models.Model):
    Type = models.CharField(max_length=30)

#class M_has_P_has_R(models.Model):
 #   Movie = models.ForeignKeyr

class Comment(models.Model):
    Movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='comments')
    CommentAuthor = models.ForeignKey(User, on_delete=models.CASCADE, related_name="author")
    Text = models.TextField()
    CreateDate = models.DateTimeField(default=django.utils.timezone.now)


    def __str__(self):
        return self.Text